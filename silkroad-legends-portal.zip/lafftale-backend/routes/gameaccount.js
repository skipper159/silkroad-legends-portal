const express = require("express");
const router = express.Router();
const authenticateToken = require("../middleware/auth");
const { sql, gamePool, gamePoolConnect } = require("../db");

// GameAccount erstellen
router.post("/create", authenticateToken, async (req, res) => {
  const { username, password } = req.body;
  if (!username || !password) return res.status(400).send("Missing credentials");

  await gamePoolConnect;
  try {
    const result = await gamePool.request()
      .input("StrUserID", sql.NVarChar, username)
      .input("password", sql.NVarChar, password) // Optional: hash
      .input("reg_ip", sql.VarChar, req.ip)
      .query(`
        INSERT INTO TB_User (StrUserID, password, reg_ip, regtime)
        VALUES (@StrUserID, @password, @reg_ip, GETDATE())
      `);

    res.status(201).send("GameAccount created");
  } catch (err) {
    console.error("Error creating game account:", err);
    res.status(500).send("Database error");
  }
});
